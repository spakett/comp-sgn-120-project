Sound pack downloaded from Freesound
----------------------------------------

"Cars driving by"

This pack of sounds contains sounds by the following user:
 - lasa01 ( https://freesound.org/people/lasa01/ )

You can find this pack online at: https://freesound.org/people/lasa01/packs/39712/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 709538__lasa01__car-driving-by-9.mp3
    * url: https://freesound.org/s/709538/
    * license: Creative Commons 0
  * 709537__lasa01__car-driving-by-8.mp3
    * url: https://freesound.org/s/709537/
    * license: Creative Commons 0
  * 709536__lasa01__car-driving-by-7.mp3
    * url: https://freesound.org/s/709536/
    * license: Creative Commons 0
  * 709535__lasa01__car-driving-by-6.mp3
    * url: https://freesound.org/s/709535/
    * license: Creative Commons 0
  * 709534__lasa01__car-driving-by-5.mp3
    * url: https://freesound.org/s/709534/
    * license: Creative Commons 0
  * 709533__lasa01__car-driving-by-4.mp3
    * url: https://freesound.org/s/709533/
    * license: Creative Commons 0
  * 709532__lasa01__car-driving-by-3.mp3
    * url: https://freesound.org/s/709532/
    * license: Creative Commons 0
  * 709531__lasa01__car-driving-by-2.mp3
    * url: https://freesound.org/s/709531/
    * license: Creative Commons 0
  * 709530__lasa01__car-driving-by-18.mp3
    * url: https://freesound.org/s/709530/
    * license: Creative Commons 0
  * 709529__lasa01__car-driving-by-17.mp3
    * url: https://freesound.org/s/709529/
    * license: Creative Commons 0
  * 709528__lasa01__car-driving-by-16.mp3
    * url: https://freesound.org/s/709528/
    * license: Creative Commons 0
  * 709527__lasa01__car-driving-by-15.mp3
    * url: https://freesound.org/s/709527/
    * license: Creative Commons 0
  * 709526__lasa01__car-driving-by-14.mp3
    * url: https://freesound.org/s/709526/
    * license: Creative Commons 0
  * 709525__lasa01__car-driving-by-13.mp3
    * url: https://freesound.org/s/709525/
    * license: Creative Commons 0
  * 709524__lasa01__car-driving-by-12.mp3
    * url: https://freesound.org/s/709524/
    * license: Creative Commons 0
  * 709523__lasa01__car-driving-by-11.mp3
    * url: https://freesound.org/s/709523/
    * license: Creative Commons 0
  * 709522__lasa01__car-driving-by-10.mp3
    * url: https://freesound.org/s/709522/
    * license: Creative Commons 0
  * 709521__lasa01__car-driving-by-1.mp3
    * url: https://freesound.org/s/709521/
    * license: Creative Commons 0


