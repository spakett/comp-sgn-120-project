Sound pack downloaded from Freesound
----------------------------------------

"car passing by"

This pack of sounds contains sounds by the following user:
 - nnymark ( https://freesound.org/people/nnymark/ )

You can find this pack online at: https://freesound.org/people/nnymark/packs/36862/


Pack description
----------------

Car passing by, recorded with Nokia 8.1 phone in Tampere, Finland.


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 659842__nnymark__car26.mp3
    * url: https://freesound.org/s/659842/
    * license: Creative Commons 0
  * 659841__nnymark__car27.mp3
    * url: https://freesound.org/s/659841/
    * license: Creative Commons 0
  * 659840__nnymark__car22.mp3
    * url: https://freesound.org/s/659840/
    * license: Creative Commons 0
  * 659839__nnymark__car23.mp3
    * url: https://freesound.org/s/659839/
    * license: Creative Commons 0
  * 659838__nnymark__car24.mp3
    * url: https://freesound.org/s/659838/
    * license: Creative Commons 0
  * 659837__nnymark__car25.mp3
    * url: https://freesound.org/s/659837/
    * license: Creative Commons 0
  * 659836__nnymark__car19.mp3
    * url: https://freesound.org/s/659836/
    * license: Creative Commons 0
  * 659835__nnymark__car2.mp3
    * url: https://freesound.org/s/659835/
    * license: Creative Commons 0
  * 659834__nnymark__car20.mp3
    * url: https://freesound.org/s/659834/
    * license: Creative Commons 0
  * 659833__nnymark__car21.mp3
    * url: https://freesound.org/s/659833/
    * license: Creative Commons 0
  * 659832__nnymark__car5.mp3
    * url: https://freesound.org/s/659832/
    * license: Creative Commons 0
  * 659831__nnymark__car4.mp3
    * url: https://freesound.org/s/659831/
    * license: Creative Commons 0
  * 659830__nnymark__car7.mp3
    * url: https://freesound.org/s/659830/
    * license: Creative Commons 0
  * 659829__nnymark__car6.mp3
    * url: https://freesound.org/s/659829/
    * license: Creative Commons 0
  * 659828__nnymark__car29.mp3
    * url: https://freesound.org/s/659828/
    * license: Creative Commons 0
  * 659827__nnymark__car28.mp3
    * url: https://freesound.org/s/659827/
    * license: Creative Commons 0
  * 659826__nnymark__car30.mp3
    * url: https://freesound.org/s/659826/
    * license: Creative Commons 0
  * 659825__nnymark__car3.mp3
    * url: https://freesound.org/s/659825/
    * license: Creative Commons 0
  * 659824__nnymark__car9.mp3
    * url: https://freesound.org/s/659824/
    * license: Creative Commons 0
  * 659823__nnymark__car8.mp3
    * url: https://freesound.org/s/659823/
    * license: Creative Commons 0
  * 659821__nnymark__car17.mp3
    * url: https://freesound.org/s/659821/
    * license: Creative Commons 0
  * 659820__nnymark__car18.mp3
    * url: https://freesound.org/s/659820/
    * license: Creative Commons 0
  * 659819__nnymark__car13.mp3
    * url: https://freesound.org/s/659819/
    * license: Creative Commons 0
  * 659818__nnymark__car14.mp3
    * url: https://freesound.org/s/659818/
    * license: Creative Commons 0
  * 659817__nnymark__car15.mp3
    * url: https://freesound.org/s/659817/
    * license: Creative Commons 0
  * 659816__nnymark__car16.mp3
    * url: https://freesound.org/s/659816/
    * license: Creative Commons 0
  * 659815__nnymark__car1.mp3
    * url: https://freesound.org/s/659815/
    * license: Creative Commons 0
  * 659814__nnymark__car10.mp3
    * url: https://freesound.org/s/659814/
    * license: Creative Commons 0
  * 659813__nnymark__car11.mp3
    * url: https://freesound.org/s/659813/
    * license: Creative Commons 0
  * 659812__nnymark__car12.mp3
    * url: https://freesound.org/s/659812/
    * license: Creative Commons 0


