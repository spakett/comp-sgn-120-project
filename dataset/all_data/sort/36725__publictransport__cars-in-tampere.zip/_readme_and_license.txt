Sound pack downloaded from Freesound
----------------------------------------

"cars in Tampere"

This pack of sounds contains sounds by the following user:
 - publictransport ( https://freesound.org/people/publictransport/ )

You can find this pack online at: https://freesound.org/people/publictransport/packs/36725/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 657295__publictransport__car21.mp3
    * url: https://freesound.org/s/657295/
    * license: Creative Commons 0
  * 657294__publictransport__car19.mp3
    * url: https://freesound.org/s/657294/
    * license: Creative Commons 0
  * 657293__publictransport__car20.mp3
    * url: https://freesound.org/s/657293/
    * license: Creative Commons 0
  * 657292__publictransport__car15.mp3
    * url: https://freesound.org/s/657292/
    * license: Creative Commons 0
  * 657291__publictransport__car16.mp3
    * url: https://freesound.org/s/657291/
    * license: Creative Commons 0
  * 657290__publictransport__car17.mp3
    * url: https://freesound.org/s/657290/
    * license: Creative Commons 0
  * 657289__publictransport__car18.mp3
    * url: https://freesound.org/s/657289/
    * license: Creative Commons 0
  * 657288__publictransport__car11.mp3
    * url: https://freesound.org/s/657288/
    * license: Creative Commons 0
  * 657287__publictransport__car12.mp3
    * url: https://freesound.org/s/657287/
    * license: Creative Commons 0
  * 657286__publictransport__car13.mp3
    * url: https://freesound.org/s/657286/
    * license: Creative Commons 0
  * 657285__publictransport__car14.mp3
    * url: https://freesound.org/s/657285/
    * license: Creative Commons 0
  * 657284__publictransport__car09.mp3
    * url: https://freesound.org/s/657284/
    * license: Creative Commons 0
  * 657283__publictransport__car10.mp3
    * url: https://freesound.org/s/657283/
    * license: Creative Commons 0
  * 657282__publictransport__car05.mp3
    * url: https://freesound.org/s/657282/
    * license: Creative Commons 0
  * 657281__publictransport__car06.mp3
    * url: https://freesound.org/s/657281/
    * license: Creative Commons 0
  * 657280__publictransport__car07.mp3
    * url: https://freesound.org/s/657280/
    * license: Creative Commons 0
  * 657279__publictransport__car08.mp3
    * url: https://freesound.org/s/657279/
    * license: Creative Commons 0
  * 657278__publictransport__car01.mp3
    * url: https://freesound.org/s/657278/
    * license: Creative Commons 0
  * 657277__publictransport__car02.mp3
    * url: https://freesound.org/s/657277/
    * license: Creative Commons 0
  * 657276__publictransport__car03.mp3
    * url: https://freesound.org/s/657276/
    * license: Creative Commons 0
  * 657275__publictransport__car04.mp3
    * url: https://freesound.org/s/657275/
    * license: Creative Commons 0


