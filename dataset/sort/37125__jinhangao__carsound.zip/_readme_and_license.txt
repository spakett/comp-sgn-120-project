Sound pack downloaded from Freesound
----------------------------------------

"CarSound"

This pack of sounds contains sounds by the following user:
 - JinhanGao ( https://freesound.org/people/JinhanGao/ )

You can find this pack online at: https://freesound.org/people/JinhanGao/packs/37125/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 664726__jinhangao__opiskelijankatu-24.m4a
    * url: https://freesound.org/s/664726/
    * license: Creative Commons 0
  * 664725__jinhangao__opiskelijankatu-25.m4a
    * url: https://freesound.org/s/664725/
    * license: Creative Commons 0
  * 664724__jinhangao__opiskelijankatu-20.m4a
    * url: https://freesound.org/s/664724/
    * license: Creative Commons 0
  * 664723__jinhangao__opiskelijankatu-21.m4a
    * url: https://freesound.org/s/664723/
    * license: Creative Commons 0
  * 664722__jinhangao__opiskelijankatu-22.m4a
    * url: https://freesound.org/s/664722/
    * license: Creative Commons 0
  * 664721__jinhangao__opiskelijankatu-23.m4a
    * url: https://freesound.org/s/664721/
    * license: Creative Commons 0
  * 664720__jinhangao__opiskelijankatu-17.m4a
    * url: https://freesound.org/s/664720/
    * license: Creative Commons 0
  * 664719__jinhangao__opiskelijankatu-18.m4a
    * url: https://freesound.org/s/664719/
    * license: Creative Commons 0
  * 664718__jinhangao__opiskelijankatu-19.m4a
    * url: https://freesound.org/s/664718/
    * license: Creative Commons 0
  * 664717__jinhangao__opiskelijankatu-2.m4a
    * url: https://freesound.org/s/664717/
    * license: Creative Commons 0
  * 664716__jinhangao__opiskelijankatu-7.m4a
    * url: https://freesound.org/s/664716/
    * license: Creative Commons 0
  * 664715__jinhangao__opiskelijankatu-32.m4a
    * url: https://freesound.org/s/664715/
    * license: Creative Commons 0
  * 664714__jinhangao__opiskelijankatu-29.m4a
    * url: https://freesound.org/s/664714/
    * license: Creative Commons 0
  * 664713__jinhangao__opiskelijankatu-27.m4a
    * url: https://freesound.org/s/664713/
    * license: Creative Commons 0
  * 664712__jinhangao__opiskelijankatu-31.m4a
    * url: https://freesound.org/s/664712/
    * license: Creative Commons 0
  * 664711__jinhangao__opiskelijankatu-30.m4a
    * url: https://freesound.org/s/664711/
    * license: Creative Commons 0
  * 664710__jinhangao__opiskelijankatu-15.m4a
    * url: https://freesound.org/s/664710/
    * license: Creative Commons 0
  * 664709__jinhangao__opiskelijankatu-16.m4a
    * url: https://freesound.org/s/664709/
    * license: Creative Commons 0
  * 664708__jinhangao__opiskelijankatu-11.m4a
    * url: https://freesound.org/s/664708/
    * license: Creative Commons 0
  * 664707__jinhangao__opiskelijankatu-12.m4a
    * url: https://freesound.org/s/664707/
    * license: Creative Commons 0
  * 664706__jinhangao__opiskelijankatu-13.m4a
    * url: https://freesound.org/s/664706/
    * license: Creative Commons 0
  * 664705__jinhangao__opiskelijankatu-14.m4a
    * url: https://freesound.org/s/664705/
    * license: Creative Commons 0
  * 664704__jinhangao__koskipuisto-2.m4a
    * url: https://freesound.org/s/664704/
    * license: Creative Commons 0
  * 664703__jinhangao__lidl-3.m4a
    * url: https://freesound.org/s/664703/
    * license: Creative Commons 0
  * 664702__jinhangao__lie-mi-2.m4a
    * url: https://freesound.org/s/664702/
    * license: Creative Commons 0
  * 664701__jinhangao__opiskelijankatu-10.m4a
    * url: https://freesound.org/s/664701/
    * license: Creative Commons 0


