Sound pack downloaded from Freesound
----------------------------------------

"Tram 10.2023"

This pack of sounds contains sounds by the following user:
 - wowaka ( https://freesound.org/people/wowaka/ )

You can find this pack online at: https://freesound.org/people/wowaka/packs/39643/


Pack description
----------------

Sounds were recorded on 29 and 30.10.2023 in Hervanta, Tampere, Finland.


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 709757__wowaka__tram20.m4a
    * url: https://freesound.org/s/709757/
    * license: Creative Commons 0
  * 709756__wowaka__tram19.m4a
    * url: https://freesound.org/s/709756/
    * license: Creative Commons 0
  * 709755__wowaka__tram18.m4a
    * url: https://freesound.org/s/709755/
    * license: Creative Commons 0
  * 709754__wowaka__tram17.m4a
    * url: https://freesound.org/s/709754/
    * license: Creative Commons 0
  * 709753__wowaka__tram16.m4a
    * url: https://freesound.org/s/709753/
    * license: Creative Commons 0
  * 709752__wowaka__tram15.m4a
    * url: https://freesound.org/s/709752/
    * license: Creative Commons 0
  * 709750__wowaka__tram14.m4a
    * url: https://freesound.org/s/709750/
    * license: Creative Commons 0
  * 709743__wowaka__tram13.m4a
    * url: https://freesound.org/s/709743/
    * license: Creative Commons 0
  * 709740__wowaka__tram12.m4a
    * url: https://freesound.org/s/709740/
    * license: Creative Commons 0
  * 709737__wowaka__tram11.m4a
    * url: https://freesound.org/s/709737/
    * license: Creative Commons 0
  * 709736__wowaka__tram10.m4a
    * url: https://freesound.org/s/709736/
    * license: Creative Commons 0
  * 709735__wowaka__tram09.m4a
    * url: https://freesound.org/s/709735/
    * license: Creative Commons 0
  * 709734__wowaka__tram08.m4a
    * url: https://freesound.org/s/709734/
    * license: Creative Commons 0
  * 709733__wowaka__tram07.m4a
    * url: https://freesound.org/s/709733/
    * license: Creative Commons 0
  * 709732__wowaka__tram06.m4a
    * url: https://freesound.org/s/709732/
    * license: Creative Commons 0
  * 709731__wowaka__tram05.m4a
    * url: https://freesound.org/s/709731/
    * license: Creative Commons 0
  * 709730__wowaka__tram04.m4a
    * url: https://freesound.org/s/709730/
    * license: Creative Commons 0
  * 709729__wowaka__tram03.m4a
    * url: https://freesound.org/s/709729/
    * license: Creative Commons 0
  * 709728__wowaka__tram02.m4a
    * url: https://freesound.org/s/709728/
    * license: Creative Commons 0
  * 709727__wowaka__tram01.m4a
    * url: https://freesound.org/s/709727/
    * license: Creative Commons 0


