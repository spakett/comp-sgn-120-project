Sound pack downloaded from Freesound
----------------------------------------

"tram passing by"

This pack of sounds contains sounds by the following user:
 - nnymark ( https://freesound.org/people/nnymark/ )

You can find this pack online at: https://freesound.org/people/nnymark/packs/36863/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 659863__nnymark__tram3.mp3
    * url: https://freesound.org/s/659863/
    * license: Creative Commons 0
  * 659862__nnymark__tram9.mp3
    * url: https://freesound.org/s/659862/
    * license: Creative Commons 0
  * 659861__nnymark__tram5.mp3
    * url: https://freesound.org/s/659861/
    * license: Creative Commons 0
  * 659860__nnymark__tram4.mp3
    * url: https://freesound.org/s/659860/
    * license: Creative Commons 0
  * 659859__nnymark__tram7.mp3
    * url: https://freesound.org/s/659859/
    * license: Creative Commons 0
  * 659858__nnymark__tram20.mp3
    * url: https://freesound.org/s/659858/
    * license: Creative Commons 0
  * 659857__nnymark__tram6.mp3
    * url: https://freesound.org/s/659857/
    * license: Creative Commons 0
  * 659856__nnymark__tram19.mp3
    * url: https://freesound.org/s/659856/
    * license: Creative Commons 0
  * 659855__nnymark__tram8.mp3
    * url: https://freesound.org/s/659855/
    * license: Creative Commons 0
  * 659854__nnymark__tram2.mp3
    * url: https://freesound.org/s/659854/
    * license: Creative Commons 0
  * 659852__nnymark__tram17.mp3
    * url: https://freesound.org/s/659852/
    * license: Creative Commons 0
  * 659851__nnymark__tram18.mp3
    * url: https://freesound.org/s/659851/
    * license: Creative Commons 0
  * 659850__nnymark__tram13.mp3
    * url: https://freesound.org/s/659850/
    * license: Creative Commons 0
  * 659849__nnymark__tram14.mp3
    * url: https://freesound.org/s/659849/
    * license: Creative Commons 0
  * 659848__nnymark__tram15.mp3
    * url: https://freesound.org/s/659848/
    * license: Creative Commons 0
  * 659847__nnymark__tram16.mp3
    * url: https://freesound.org/s/659847/
    * license: Creative Commons 0
  * 659846__nnymark__tram1.mp3
    * url: https://freesound.org/s/659846/
    * license: Creative Commons 0
  * 659845__nnymark__tram10.mp3
    * url: https://freesound.org/s/659845/
    * license: Creative Commons 0
  * 659844__nnymark__tram11.mp3
    * url: https://freesound.org/s/659844/
    * license: Creative Commons 0
  * 659843__nnymark__tram12.mp3
    * url: https://freesound.org/s/659843/
    * license: Creative Commons 0


