Sound pack downloaded from Freesound
----------------------------------------

"car sounds"

This pack of sounds contains sounds by the following user:
 - audiosophie ( https://freesound.org/people/audiosophie/ )

You can find this pack online at: https://freesound.org/people/audiosophie/packs/37062/


Pack description
----------------

NOTE conversion to wav failed even though it shows these files correctly. Files seem to actually be in m4a files and with locally converting them you can easily get wav format


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 663296__audiosophie__car3.wav
    * url: https://freesound.org/s/663296/
    * license: Creative Commons 0
  * 663295__audiosophie__car9.wav
    * url: https://freesound.org/s/663295/
    * license: Creative Commons 0
  * 663294__audiosophie__car5.wav
    * url: https://freesound.org/s/663294/
    * license: Creative Commons 0
  * 663293__audiosophie__car4.wav
    * url: https://freesound.org/s/663293/
    * license: Creative Commons 0
  * 663292__audiosophie__car7.wav
    * url: https://freesound.org/s/663292/
    * license: Creative Commons 0
  * 663291__audiosophie__car20.wav
    * url: https://freesound.org/s/663291/
    * license: Creative Commons 0
  * 663290__audiosophie__car6.wav
    * url: https://freesound.org/s/663290/
    * license: Creative Commons 0
  * 663289__audiosophie__car19.wav
    * url: https://freesound.org/s/663289/
    * license: Creative Commons 0
  * 663288__audiosophie__car8.wav
    * url: https://freesound.org/s/663288/
    * license: Creative Commons 0
  * 663287__audiosophie__car2.wav
    * url: https://freesound.org/s/663287/
    * license: Creative Commons 0
  * 663284__audiosophie__car17.wav
    * url: https://freesound.org/s/663284/
    * license: Creative Commons 0
  * 663283__audiosophie__car18.wav
    * url: https://freesound.org/s/663283/
    * license: Creative Commons 0
  * 663282__audiosophie__car13.wav
    * url: https://freesound.org/s/663282/
    * license: Creative Commons 0
  * 663281__audiosophie__car14.wav
    * url: https://freesound.org/s/663281/
    * license: Creative Commons 0
  * 663280__audiosophie__car15.wav
    * url: https://freesound.org/s/663280/
    * license: Creative Commons 0
  * 663279__audiosophie__car16.wav
    * url: https://freesound.org/s/663279/
    * license: Creative Commons 0
  * 663278__audiosophie__car1.wav
    * url: https://freesound.org/s/663278/
    * license: Creative Commons 0
  * 663277__audiosophie__car10.wav
    * url: https://freesound.org/s/663277/
    * license: Creative Commons 0
  * 663276__audiosophie__car11.wav
    * url: https://freesound.org/s/663276/
    * license: Creative Commons 0
  * 663275__audiosophie__car12.wav
    * url: https://freesound.org/s/663275/
    * license: Creative Commons 0


