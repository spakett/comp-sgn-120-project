Sound pack downloaded from Freesound
----------------------------------------

"Car audio"

This pack of sounds contains sounds by the following user:
 - araatikainen ( https://freesound.org/people/araatikainen/ )

You can find this pack online at: https://freesound.org/people/araatikainen/packs/39935/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 714634__araatikainen__carsound9.wav
    * url: https://freesound.org/s/714634/
    * license: Creative Commons 0
  * 714633__araatikainen__carsound8.wav
    * url: https://freesound.org/s/714633/
    * license: Creative Commons 0
  * 714632__araatikainen__carsound7.wav
    * url: https://freesound.org/s/714632/
    * license: Creative Commons 0
  * 714631__araatikainen__carsound6.wav
    * url: https://freesound.org/s/714631/
    * license: Creative Commons 0
  * 714630__araatikainen__carsound5.wav
    * url: https://freesound.org/s/714630/
    * license: Creative Commons 0
  * 714629__araatikainen__carsound4.wav
    * url: https://freesound.org/s/714629/
    * license: Creative Commons 0
  * 714628__araatikainen__carsound3.wav
    * url: https://freesound.org/s/714628/
    * license: Creative Commons 0
  * 714627__araatikainen__carsound20.wav
    * url: https://freesound.org/s/714627/
    * license: Creative Commons 0
  * 714626__araatikainen__carsound2.wav
    * url: https://freesound.org/s/714626/
    * license: Creative Commons 0
  * 714625__araatikainen__carsound19.wav
    * url: https://freesound.org/s/714625/
    * license: Creative Commons 0
  * 714624__araatikainen__carsound18.wav
    * url: https://freesound.org/s/714624/
    * license: Creative Commons 0
  * 714623__araatikainen__carsound17.wav
    * url: https://freesound.org/s/714623/
    * license: Creative Commons 0
  * 714622__araatikainen__carsound16.wav
    * url: https://freesound.org/s/714622/
    * license: Creative Commons 0
  * 714621__araatikainen__carsound15.wav
    * url: https://freesound.org/s/714621/
    * license: Creative Commons 0
  * 714620__araatikainen__carsound14.wav
    * url: https://freesound.org/s/714620/
    * license: Creative Commons 0
  * 714619__araatikainen__carsound13.wav
    * url: https://freesound.org/s/714619/
    * license: Creative Commons 0
  * 714618__araatikainen__carsound12.wav
    * url: https://freesound.org/s/714618/
    * license: Creative Commons 0
  * 714617__araatikainen__carsound11.wav
    * url: https://freesound.org/s/714617/
    * license: Creative Commons 0
  * 714616__araatikainen__carsound10.wav
    * url: https://freesound.org/s/714616/
    * license: Creative Commons 0
  * 714615__araatikainen__carsound1.wav
    * url: https://freesound.org/s/714615/
    * license: Creative Commons 0


