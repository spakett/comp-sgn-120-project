Sound pack downloaded from Freesound
----------------------------------------

"TramSound"

This pack of sounds contains sounds by the following user:
 - JinhanGao ( https://freesound.org/people/JinhanGao/ )

You can find this pack online at: https://freesound.org/people/JinhanGao/packs/37127/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 664746__jinhangao__opiskelijankatu-43.m4a
    * url: https://freesound.org/s/664746/
    * license: Creative Commons 0
  * 664745__jinhangao__pizza-kebab-selvi-3.m4a
    * url: https://freesound.org/s/664745/
    * license: Creative Commons 0
  * 664744__jinhangao__opiskelijankatu-6.m4a
    * url: https://freesound.org/s/664744/
    * license: Creative Commons 0
  * 664743__jinhangao__opiskelijankatu-5.m4a
    * url: https://freesound.org/s/664743/
    * license: Creative Commons 0
  * 664742__jinhangao__opiskelijankatu.m4a
    * url: https://freesound.org/s/664742/
    * license: Creative Commons 0
  * 664741__jinhangao__opiskelijankatu-41.m4a
    * url: https://freesound.org/s/664741/
    * license: Creative Commons 0
  * 664740__jinhangao__opiskelijankatu-8.m4a
    * url: https://freesound.org/s/664740/
    * license: Creative Commons 0
  * 664739__jinhangao__opiskelijankatu-39.m4a
    * url: https://freesound.org/s/664739/
    * license: Creative Commons 0
  * 664738__jinhangao__pizza-kebab-selvi-2.m4a
    * url: https://freesound.org/s/664738/
    * license: Creative Commons 0
  * 664737__jinhangao__opiskelijankatu-40.m4a
    * url: https://freesound.org/s/664737/
    * license: Creative Commons 0
  * 664736__jinhangao__opiskelijankatu-37.m4a
    * url: https://freesound.org/s/664736/
    * license: Creative Commons 0
  * 664735__jinhangao__opiskelijankatu-38.m4a
    * url: https://freesound.org/s/664735/
    * license: Creative Commons 0
  * 664734__jinhangao__opiskelijankatu-33.m4a
    * url: https://freesound.org/s/664734/
    * license: Creative Commons 0
  * 664733__jinhangao__opiskelijankatu-34.m4a
    * url: https://freesound.org/s/664733/
    * license: Creative Commons 0
  * 664732__jinhangao__opiskelijankatu-35.m4a
    * url: https://freesound.org/s/664732/
    * license: Creative Commons 0
  * 664731__jinhangao__opiskelijankatu-36.m4a
    * url: https://freesound.org/s/664731/
    * license: Creative Commons 0
  * 664730__jinhangao__hameenkatu.m4a
    * url: https://freesound.org/s/664730/
    * license: Creative Commons 0
  * 664729__jinhangao__koskipuisto.m4a
    * url: https://freesound.org/s/664729/
    * license: Creative Commons 0
  * 664728__jinhangao__lie-mi-3.m4a
    * url: https://freesound.org/s/664728/
    * license: Creative Commons 0
  * 664727__jinhangao__lie-mi.m4a
    * url: https://freesound.org/s/664727/
    * license: Creative Commons 0


