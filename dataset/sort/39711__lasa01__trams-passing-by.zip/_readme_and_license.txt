Sound pack downloaded from Freesound
----------------------------------------

"Trams passing by"

This pack of sounds contains sounds by the following user:
 - lasa01 ( https://freesound.org/people/lasa01/ )

You can find this pack online at: https://freesound.org/people/lasa01/packs/39711/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 709561__lasa01__tram-passing-by-9.mp3
    * url: https://freesound.org/s/709561/
    * license: Creative Commons 0
  * 709560__lasa01__tram-passing-by-8.mp3
    * url: https://freesound.org/s/709560/
    * license: Creative Commons 0
  * 709559__lasa01__tram-passing-by-7.mp3
    * url: https://freesound.org/s/709559/
    * license: Creative Commons 0
  * 709558__lasa01__tram-passing-by-6.mp3
    * url: https://freesound.org/s/709558/
    * license: Creative Commons 0
  * 709557__lasa01__tram-passing-by-5.mp3
    * url: https://freesound.org/s/709557/
    * license: Creative Commons 0
  * 709556__lasa01__tram-passing-by-4.mp3
    * url: https://freesound.org/s/709556/
    * license: Creative Commons 0
  * 709555__lasa01__tram-passing-by-3.mp3
    * url: https://freesound.org/s/709555/
    * license: Creative Commons 0
  * 709554__lasa01__tram-passing-by-2.mp3
    * url: https://freesound.org/s/709554/
    * license: Creative Commons 0
  * 709553__lasa01__tram-passing-by-13.mp3
    * url: https://freesound.org/s/709553/
    * license: Creative Commons 0
  * 709552__lasa01__tram-passing-by-12.mp3
    * url: https://freesound.org/s/709552/
    * license: Creative Commons 0
  * 709551__lasa01__tram-passing-by-11.mp3
    * url: https://freesound.org/s/709551/
    * license: Creative Commons 0
  * 709540__lasa01__tram-passing-by-10.mp3
    * url: https://freesound.org/s/709540/
    * license: Creative Commons 0
  * 709539__lasa01__tram-passing-by-1.mp3
    * url: https://freesound.org/s/709539/
    * license: Creative Commons 0


