Sound pack downloaded from Freesound
----------------------------------------

"trams in Tampere"

This pack of sounds contains sounds by the following user:
 - publictransport ( https://freesound.org/people/publictransport/ )

You can find this pack online at: https://freesound.org/people/publictransport/packs/36726/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 657323__publictransport__tram19.mp3
    * url: https://freesound.org/s/657323/
    * license: Creative Commons 0
  * 657322__publictransport__tram20.mp3
    * url: https://freesound.org/s/657322/
    * license: Creative Commons 0
  * 657321__publictransport__tram15.mp3
    * url: https://freesound.org/s/657321/
    * license: Creative Commons 0
  * 657320__publictransport__tram16.mp3
    * url: https://freesound.org/s/657320/
    * license: Creative Commons 0
  * 657319__publictransport__tram17.mp3
    * url: https://freesound.org/s/657319/
    * license: Creative Commons 0
  * 657318__publictransport__tram18.mp3
    * url: https://freesound.org/s/657318/
    * license: Creative Commons 0
  * 657317__publictransport__tram11.mp3
    * url: https://freesound.org/s/657317/
    * license: Creative Commons 0
  * 657316__publictransport__tram12.mp3
    * url: https://freesound.org/s/657316/
    * license: Creative Commons 0
  * 657315__publictransport__tram13.mp3
    * url: https://freesound.org/s/657315/
    * license: Creative Commons 0
  * 657314__publictransport__tram14.mp3
    * url: https://freesound.org/s/657314/
    * license: Creative Commons 0
  * 657313__publictransport__tram26.mp3
    * url: https://freesound.org/s/657313/
    * license: Creative Commons 0
  * 657312__publictransport__tram25.mp3
    * url: https://freesound.org/s/657312/
    * license: Creative Commons 0
  * 657311__publictransport__tram28.mp3
    * url: https://freesound.org/s/657311/
    * license: Creative Commons 0
  * 657310__publictransport__tram27.mp3
    * url: https://freesound.org/s/657310/
    * license: Creative Commons 0
  * 657309__publictransport__tram22.mp3
    * url: https://freesound.org/s/657309/
    * license: Creative Commons 0
  * 657308__publictransport__tram21.mp3
    * url: https://freesound.org/s/657308/
    * license: Creative Commons 0
  * 657307__publictransport__tram24.mp3
    * url: https://freesound.org/s/657307/
    * license: Creative Commons 0
  * 657306__publictransport__tram23.mp3
    * url: https://freesound.org/s/657306/
    * license: Creative Commons 0
  * 657305__publictransport__tram09.mp3
    * url: https://freesound.org/s/657305/
    * license: Creative Commons 0
  * 657304__publictransport__tram10.mp3
    * url: https://freesound.org/s/657304/
    * license: Creative Commons 0
  * 657303__publictransport__tram05.mp3
    * url: https://freesound.org/s/657303/
    * license: Creative Commons 0
  * 657302__publictransport__tram06.mp3
    * url: https://freesound.org/s/657302/
    * license: Creative Commons 0
  * 657301__publictransport__tram07.mp3
    * url: https://freesound.org/s/657301/
    * license: Creative Commons 0
  * 657300__publictransport__tram08.mp3
    * url: https://freesound.org/s/657300/
    * license: Creative Commons 0
  * 657299__publictransport__tram01.mp3
    * url: https://freesound.org/s/657299/
    * license: Creative Commons 0
  * 657298__publictransport__tram02.mp3
    * url: https://freesound.org/s/657298/
    * license: Creative Commons 0
  * 657297__publictransport__tram03.mp3
    * url: https://freesound.org/s/657297/
    * license: Creative Commons 0
  * 657296__publictransport__tram04.mp3
    * url: https://freesound.org/s/657296/
    * license: Creative Commons 0


