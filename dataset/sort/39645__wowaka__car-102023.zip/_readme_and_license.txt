Sound pack downloaded from Freesound
----------------------------------------

"Car 10.2023"

This pack of sounds contains sounds by the following user:
 - wowaka ( https://freesound.org/people/wowaka/ )

You can find this pack online at: https://freesound.org/people/wowaka/packs/39645/


Pack description
----------------

Sounds were recorded on 29 and 30.10.2023 in Hervanta, Tampere, Finland.


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 709807__wowaka__car24.m4a
    * url: https://freesound.org/s/709807/
    * license: Creative Commons 0
  * 709806__wowaka__car23.m4a
    * url: https://freesound.org/s/709806/
    * license: Creative Commons 0
  * 709805__wowaka__car22.m4a
    * url: https://freesound.org/s/709805/
    * license: Creative Commons 0
  * 709804__wowaka__car21.m4a
    * url: https://freesound.org/s/709804/
    * license: Creative Commons 0
  * 709803__wowaka__car20.m4a
    * url: https://freesound.org/s/709803/
    * license: Creative Commons 0
  * 709802__wowaka__car19.m4a
    * url: https://freesound.org/s/709802/
    * license: Creative Commons 0
  * 709801__wowaka__car18.m4a
    * url: https://freesound.org/s/709801/
    * license: Creative Commons 0
  * 709800__wowaka__car17.m4a
    * url: https://freesound.org/s/709800/
    * license: Creative Commons 0
  * 709799__wowaka__car16.m4a
    * url: https://freesound.org/s/709799/
    * license: Creative Commons 0
  * 709798__wowaka__car15.m4a
    * url: https://freesound.org/s/709798/
    * license: Creative Commons 0
  * 709797__wowaka__car14.m4a
    * url: https://freesound.org/s/709797/
    * license: Creative Commons 0
  * 709796__wowaka__car13.m4a
    * url: https://freesound.org/s/709796/
    * license: Creative Commons 0
  * 709795__wowaka__car12.m4a
    * url: https://freesound.org/s/709795/
    * license: Creative Commons 0
  * 709794__wowaka__car11.m4a
    * url: https://freesound.org/s/709794/
    * license: Creative Commons 0
  * 709793__wowaka__car10.m4a
    * url: https://freesound.org/s/709793/
    * license: Creative Commons 0
  * 709792__wowaka__car09.m4a
    * url: https://freesound.org/s/709792/
    * license: Creative Commons 0
  * 709791__wowaka__car08.m4a
    * url: https://freesound.org/s/709791/
    * license: Creative Commons 0
  * 709790__wowaka__car07.m4a
    * url: https://freesound.org/s/709790/
    * license: Creative Commons 0
  * 709789__wowaka__car06.m4a
    * url: https://freesound.org/s/709789/
    * license: Creative Commons 0
  * 709788__wowaka__car05.m4a
    * url: https://freesound.org/s/709788/
    * license: Creative Commons 0
  * 709787__wowaka__car04.m4a
    * url: https://freesound.org/s/709787/
    * license: Creative Commons 0
  * 709786__wowaka__car03.m4a
    * url: https://freesound.org/s/709786/
    * license: Creative Commons 0
  * 709785__wowaka__car02.m4a
    * url: https://freesound.org/s/709785/
    * license: Creative Commons 0
  * 709784__wowaka__car01.m4a
    * url: https://freesound.org/s/709784/
    * license: Creative Commons 0


